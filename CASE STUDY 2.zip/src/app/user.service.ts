
import { Injectable } from '@angular/core';

// add these things for subscribing and observeables
import { HttpClient } from '@angular/common/Http';

import { Observable } from 'rxjs';
import { course } from './course'
@Injectable({
  providedIn: 'root'
})
export class UserService {

  public _url = 'http://localhost:4004/get';
   public _url1 = 'http://localhost:4004/getCourses';

  constructor(private http: HttpClient) { }

  getData(): Observable<course[]> {
    return this.http.get<course[]>(this._url);
  }

   getCourses(): Observable<any> {
    return this.http.get<any>(this._url1);
  }
   postData(ename: string, eduration: number): Observable<any> {
    return this.http.post('http://localhost:4004/add', {
      courseName: ename,
      courseDuration: eduration
    });
  }
}
