import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service'
@Component({
  selector: 'app-courses-with-json',
  templateUrl: './courses-with-json.component.html',
  styleUrls: ['./courses-with-json.component.css']
})
export class CoursesWithJSONComponent implements OnInit {
  public courseJ = [];
  
  constructor(public userService: UserService) { }

  ngOnInit() {
    this.getCourses();
  }

  getCourses() {
    this.userService.getCourses().subscribe(data => this.courseJ = data);
    return false;
  }
}
