import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddComponent } from './add/add.component'
// import {SearchComponent} from './search/search.component'
import { CoursesWithJSONComponent } from './courses-with-json/courses-with-json.component';
const routes: Routes = [
  { path: 'addCourses', component: AddComponent },
  { path: 'courseWithJSON', component: CoursesWithJSONComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})
export class AppRoutingModule {



}