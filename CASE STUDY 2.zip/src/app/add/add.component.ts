import { Component, OnInit } from '@angular/core';
import {
  ReactiveFormsModule,
  FormsModule,
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic'
import { UserService } from '../user.service'
import { course } from '../course'
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
public courseD;
  constructor(private userService: UserService) { }
  public course: course[] = [];
  ngOnInit() {
    this.getData();
    this.createFormControls();
    this.createForm();
  }

  getData() {
    this.userService.getData().subscribe(data => this.course = data);
    //console.log(this.data);
    return false;
  }
  myform: FormGroup;
  cName: FormControl;
  cDuration: FormControl;

coursename:string;
courseduration:number;
  createFormControls() {
    this.cName = new FormControl('', Validators.required);

    this.cDuration = new FormControl('', Validators.required);

  }

  createForm() {
    this.myform = new FormGroup({

      cName: this.cName,

      cDuration: this.cDuration,

    });
  }
  getDuration(courseName: string) {
    for (var i = 0; i < this.course.length; i++) {
      if (courseName == this.course[i].courseName) {
        // alert("Duration of " + this.course[i].courseName + " is " + this.course[i].courseDuration);
        this.courseD =this.course[i].courseDuration;
      }
    }
  }

   postData() {
    this.userService.postData(this.coursename, this.courseduration).subscribe();
    // console.log(this.uname);
    // console.log(this.age);
    this.getData();
  }
  onSubmit(data) {
    if (this.myform.valid) {
      console.log("Course Name :" + data.cName);

      console.log("Course Duration :" + data.cDuration);
    }
    else {
      alert("All fields are *mandatory");
    }
  }
}

